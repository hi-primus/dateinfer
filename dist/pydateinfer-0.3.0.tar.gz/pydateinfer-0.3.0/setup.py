from distutils.core import setup

setup(name='pydateinfer',
      version='0.3.0',
      description='Infers date format from examples',
      long_description="""Uses a series of pattern matching and rewriting rules to compute a "best guess" datetime.strptime format string give a list of example date strings.""",
      author='Jeffrey Starr',
      author_email='will@pedalwrencher.com',
      url='https://github.com/wdm0006/dateinfer',
      packages=['dateinfer'],
      classifiers=[
          'Development Status :: 4 - Beta',
          'Intended Audience :: Developers',
          'License :: OSI Approved :: Apache Software License',
          'Operating System :: OS Independent',
          'Programming Language :: Python',
          'Programming Language :: Python :: 2.7',
          'Programming Language :: Python :: 3',
          'Topic :: Software Development :: Libraries :: Python Modules',
      ],
      install_requires=['pytz']
      )
