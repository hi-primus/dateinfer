__author__ = 'jeffrey.starr@ztoztechnologies.com'

from dateinfer.infer import infer
